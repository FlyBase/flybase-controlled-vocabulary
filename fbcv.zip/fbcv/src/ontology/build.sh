#!/bin/sh
./run.sh make all
