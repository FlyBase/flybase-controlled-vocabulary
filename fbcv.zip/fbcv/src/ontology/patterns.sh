#!/bin/sh
./run.sh make patterns
